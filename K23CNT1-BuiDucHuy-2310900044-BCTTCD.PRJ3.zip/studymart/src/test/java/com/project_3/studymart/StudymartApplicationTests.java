package com.project_3.studymart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudymartApplicationTests {

	@Test
	void contextLoads() {
	}

}
