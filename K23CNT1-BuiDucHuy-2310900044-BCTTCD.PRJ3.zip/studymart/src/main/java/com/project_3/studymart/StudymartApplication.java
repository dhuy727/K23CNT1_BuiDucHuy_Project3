package com.project_3.studymart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudymartApplication {

	public static void main(String[] args) {

        SpringApplication.run(StudymartApplication.class, args);
	}

}
