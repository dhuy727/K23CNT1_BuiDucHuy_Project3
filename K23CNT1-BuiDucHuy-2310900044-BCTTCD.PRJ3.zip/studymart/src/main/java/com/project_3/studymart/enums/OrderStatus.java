package com.project_3.studymart.enums;

public enum OrderStatus {
    PENDING,
    PAID,
    SHIPPING,
    DONE,
    CANCEL,
    NEW
}
